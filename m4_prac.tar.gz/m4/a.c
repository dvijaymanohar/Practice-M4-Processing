
#include <stdio.h>

//define(BuildDate, `syscmd(date)')
int main(int argc, char *argv[])
{
    //char a[] = "BuildDate\";
    printf("%s %s\n", __DATE__, __TIME__);

    //printf("Build Information: %s\n", a);

    return 0;
}
