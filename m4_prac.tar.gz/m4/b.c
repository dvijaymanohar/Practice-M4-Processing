
#include <stdio.h>


int main(int argc, char *argv[])
{
    char a[] = "Thu 29 Aug 2019 07:25:28 AM PDT
\";

    printf("Build Information: %s\n", a);
    return 0;
}
